
public class Main {
    public static void main(String[] args) {
        ListaDoblementeEnlazada lista = new ListaDoblementeEnlazada();
        lista.insertarInicio(3);
        lista.mostrar();
        lista.insertarInicio(2);
        lista.mostrar();
        lista.insertarFinal(5);
        lista.mostrar();
        lista.insertarInicio(1);
        lista.mostrar();
        lista.insertarInicio(1);
        lista.mostrar();
        lista.insertarFinal(8);
        lista.mostrar();
        Nodo a = lista.buscar(3);
        System.out.println((a != null)? "3 si esta" : "3 no esta" );
        Nodo b = lista.buscar(7);
        System.out.println((b != null)? "7 si esta" : "7 no esta" );
        lista.eliminarFinal();
        lista.mostrar();
        lista.eliminarInicio();
        lista.mostrar();
        lista.eliminarFinal();
        lista.mostrar();
        lista.eliminarFinal();
        lista.mostrar();
        lista.eliminarFinal();
        lista.mostrar();
        lista.eliminarFinal();
        lista.mostrar();
        lista.eliminarFinal();
        lista.mostrar();
        lista.eliminarFinal();
        lista.mostrar();
    }
}
